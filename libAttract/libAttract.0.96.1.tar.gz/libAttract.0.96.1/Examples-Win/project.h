#ifndef PROJECT_H
#define PROJECT_H
#pragma once

#define EXAMPLE 1

#endif

