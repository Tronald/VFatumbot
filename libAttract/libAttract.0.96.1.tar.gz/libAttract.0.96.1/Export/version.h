#ifndef VERSION_H
#define VERSION_H
#pragma once

//libAttract VERSION
#define VERSION_MAJOR 0
#define VERSION_MINOR 96
#define VERSION_PATCH 1

#endif
