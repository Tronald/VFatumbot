#ifndef VERSION_H
#define VERSION_H
#pragma once

//libAttract VERSION
#define VERSION_MAJOR 0
#define VERSION_MINOR 95
#define VERSION_PATCH 5

#endif
