#ifndef DLL_H
#define DLL_H

#pragma once

#define LIBATTRACT_EXPORTS 1
#include "export_h.h"

#endif

